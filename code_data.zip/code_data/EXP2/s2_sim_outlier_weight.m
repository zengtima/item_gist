n_trials = 8; 

n_o = 79;

start = 0;

sim_step = 81;
sim_inc = (1 - 0)/(sim_step-1);


cd stimuli_data;

load dot;
load out;

cd participants;

loc(:, 1) = dotX;
loc(:, 2) = dotY;

loc = sortrows(loc,1); %sort loc by order

for s = 1:n_o
    

    findday1 = dir([num2str(s) '_day1.mat']);
    findday2 = dir([num2str(s) '_day2.mat']);
    findday3 = dir([num2str(s) '_day3.mat']);
    
    if (isempty(findday1) == 1) || (isempty(findday2) == 1) || (isempty(findday3) == 1)
        ind1_dis = nan;
        ind1 = [nan, nan];
        gist1 = [nan, nan];
        gist1_dis = nan;
        
        ind2_dis = nan;
        ind2 = [nan, nan];
        gist2 = [nan, nan];
        gist2_dis = nan;
        
        ind3_dis = nan;
        ind3 = [nan, nan];
        gist3 = [nan, nan];
        gist3_dis = nan;
        
        optimal_weight(s,:) = nan;    
        sim_dis_est_gist_gist1(s,:)=nan;
        sim_dis_est_gist_gist2(s,:)=nan;
        sim_dis_est_gist_gist3(s,:)=nan;

    else
        
    load([num2str(s) '_day1.mat']);
    load([num2str(s) '_day2.mat']);
    load([num2str(s) '_day3.mat']);
        

    sort1_o(:,1) = ind1_dis;
    sort1_o(:,2) = dotX(random_ind1);
    sort1_o(:,3) = dotY(random_ind1);
    sort1_o(:,4) = ind1(:,1);
    sort1_o(:,5) = ind1(:,2);
    [sort1_o, sort1_order] = sortrows(sort1_o,2);
    dind1_sort_o(s,:) = sort1_o(:,1);
    ind1_sort_o(:,1) = sort1_o(:,4);
    ind1_sort_o(:,2) = sort1_o(:,5);
    ind1X_sort_o(s,:) = sort1_o(:,4);
    ind1Y_sort_o(s,:) = sort1_o(:,5);

    %Session 1
    weight1 = start;
    est_gist1 = [];
    
    for sim = 1: sim_step
        
        weight1 = weight1+(sim-1)*sim_inc;
        
        est_gist1(sim,:) = [weight1*ind1X_sort_o(s,1)+sum((1-weight1)*ind1X_sort_o(s,2:n_trials)/(n_trials-1)),
           weight1*ind1Y_sort_o(s,1)+sum((1-weight1)*ind1Y_sort_o(s, 2:n_trials)/(n_trials-1))];
        
       weight1 = start;
    end    
    
    sim_dis_est_gist_gist1(s,:)=pdist2(est_gist1, gist1, 'euclidean');
    
    min_temp1 = min(sim_dis_est_gist_gist1(s,:));
    optimal_weight(s,1) = start+(find(sim_dis_est_gist_gist1(s,:)==min_temp1)-1)*sim_inc;
    
    %Session 2
    sort2_o(:,1) = ind2_dis;
    sort2_o(:,2) = dotX(random_ind2);
    sort2_o(:,3) = dotY(random_ind2);
    sort2_o(:,4) = ind2(:,1);
    sort2_o(:,5) = ind2(:,2);
    [sort2_o, sort2_order] = sortrows(sort2_o,2);
    dind2_sort_o(s,:) = sort2_o(:,1);
    ind2_sort_o(:,1) = sort2_o(:,4);
    ind2_sort_o(:,2) = sort2_o(:,5);
    ind2X_sort_o(s,:) = sort2_o(:,4);
    ind2Y_sort_o(s,:) = sort2_o(:,5);
    
    weight2 = start;
    est_gist2 = [];
    
    for sim = 1: sim_step
        
        weight2 = weight2+(sim-1)*sim_inc;
        
        est_gist2(sim,:) = [weight2*ind2X_sort_o(s,1)+sum((1-weight2)*ind2X_sort_o(s,2:n_trials)/(n_trials-1)),
           weight2*ind2Y_sort_o(s,1)+sum((1-weight2)*ind2Y_sort_o(s, 2:n_trials)/(n_trials-1))];
        
       weight2 = start;
    end    

    
    sim_dis_est_gist_gist2(s,:)=pdist2(est_gist2, gist2, 'euclidean');
    
    min_temp2 = min(sim_dis_est_gist_gist2(s,:));
    optimal_weight(s,2) = start+(find(sim_dis_est_gist_gist2(s,:)==min_temp2)-1)*sim_inc;
    
    %Session 3
    sort3_o = [];
    sort3_o(:,1) = ind3_dis;
    sort3_o(:,2) = dotX(random_ind3);
    sort3_o(:,3) = dotY(random_ind3);
    sort3_o(:,4) = ind3(:,1);
    sort3_o(:,5) = ind3(:,2);
    [sort3_o, sort3_order] = sortrows(sort3_o,2);
    dind3_sort_o(s,:) = sort3_o(:,1);
    ind3_sort_o(:,1) = sort3_o(:,4);
    ind3_sort_o(:,2) = sort3_o(:,5);
    ind3X_sort_o(s,:) = sort3_o(:,4);
    ind3Y_sort_o(s,:) = sort3_o(:,5);
    
    weight3 = start;
    est_gist3 = [];
    
    for sim = 1: sim_step
        
        weight3 = weight3+(sim-1)*sim_inc;
        
        est_gist3(sim,:) = [weight3*ind3X_sort_o(s,1)+sum((1-weight3)*ind3X_sort_o(s,2:n_trials)/(n_trials-1)),
           weight3*ind3Y_sort_o(s,1)+sum((1-weight3)*ind3Y_sort_o(s, 2:n_trials)/(n_trials-1))];
        
       weight3 = start;
    end    
    
    sim_dis_est_gist_gist3(s,:)=pdist2(est_gist3, gist3, 'euclidean');
    
    min_temp3 = min(sim_dis_est_gist_gist3(s,:));
    optimal_weight(s,3) = start+(find(sim_dis_est_gist_gist3(s,:)==min_temp3)-1)*sim_inc;
    
    
    end
    
    
end  

cd ../../s1_output;

label = {'ID';'day';'optimal_weight';};

out_w1(:,1) = 1:n_o; %ID
out_w1(:,2) = 1;%day
out_w1(:,3) = optimal_weight(:,1); %optimal weight of the outlier

opt_w1Table = array2table(out_w1,'VariableNames',label);
writetable(opt_w1Table, 'out_w1.csv')

out_w2(:,1) = 1:n_o; %ID
out_w2(:,2) = 2;%day
out_w2(:,3) = optimal_weight(:,2); %optimal weight of the outlier

opt_w2Table = array2table(out_w2,'VariableNames',label);
writetable(opt_w2Table, 'out_w2.csv')

out_w3(:,1) = 1:n_o; %ID
out_w3(:,2) = 3;%day
out_w3(:,3) = optimal_weight(:,3); %optimal weight of the outlier

opt_w3Table = array2table(out_w3,'VariableNames',label);
writetable(opt_w3Table, 'out_w3.csv')

cd ..;