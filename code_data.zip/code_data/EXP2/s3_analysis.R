if(!require(MASS)){install.packages('MASS')}
if(!require(R.matlab)){install.packages('R.matlab')}
if(!require(ggplot2)){install.packages('ggplot2')}
if(!require(magrittr)){install.packages('magrittr')}
if(!require(ggpubr)){install.packages('ggpubr')}
if(!require(psych)){install.packages('psych')}
if(!require(Hmisc)){install.packages('Hmisc')}
if(!require(readr)){install.packages('readr')}
if(!require(plyr)){install.packages('plyr')}
if(!require(readr)){install.packages('readr')}
if(!require(reshape2)){install.packages('reshape2')}

if(!require(mblm)){install.packages('mblm')}
if(!require(quantreg)){install.packages('quantreg')}
if(!require(rcompanion)){install.packages('rcompanion')}
if(!require(mgcv)){install.packages('mgcv')}
if(!require(lmtest)){install.packages('lmtest')}
if(!require(lmerTest)){install.packages('lmerTest')}

if(!require(ARTool)){install.packages('ARTool')}
if(!require(emmeans)){install.packages('emmeans')}
if(!require(interactions)){install.packages('interactions')}

library('MASS')
library('R.matlab')
library('ggplot2')
library('magrittr')
library('ggpubr')
library('psych')
library('Hmisc')
library('readr')
library("plyr")
library('reshape2')

library('mblm')
library('quantreg')
library('rcompanion')
library('mgcv')
library('lmtest')
library('lmerTest')

library('ARTool')
library('emmeans')
library('interactions')

#you need to set the working directory to be code_data/EXP2
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

source('read_data.R')

###### Error Analysis #####
#the change of item and gist error
shapiro.test(as.numeric(change_item_gist_error[change_item_gist_error$memoryType == "dind" ,"errorChange"]))
shapiro.test(as.numeric(change_item_gist_error[change_item_gist_error$memoryType == "dgist" ,"errorChange"]))

model = art(errorChange ~ day + memoryType + day:memoryType + (1|ID),
            data = change_item_gist_error)
anova(model)

#dind against chance
wilcox.test(d1$dind, mu = dind_chance, exact = FALSE)
wilcox.test(d2$dind, mu = dind_chance, exact = FALSE)
wilcox.test(d3$dind, mu = dind_chance, exact = FALSE)

#gistagainst chance
wilcox.test(d1$dgist, mu = dgist_chance, exact = FALSE)
wilcox.test(d2$dgist, mu = dgist_chance, exact = FALSE)
wilcox.test(d3$dgist, mu = dgist_chance, exact = FALSE)

#source('wilcox_test.R')
w_dind_24h_1m=wilcox.test(change_item_gist_error[change_item_gist_error$memoryType == "dind" & change_item_gist_error$day == 2,"errorChange"],
                          change_item_gist_error[change_item_gist_error$memoryType == "dind" & change_item_gist_error$day == 3,"errorChange"],
                          exact = FALSE,
                          paired = TRUE)
w_dind_24h_1m
w_dind_24h_1m$z_val#z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio


w_dgist_24h_1m=wilcox.test(change_item_gist_error[change_item_gist_error$memoryType == "dgist" & change_item_gist_error$day == 2,"errorChange"],
                          change_item_gist_error[change_item_gist_error$memoryType == "dgist" & change_item_gist_error$day == 3,"errorChange"],
                          exact = FALSE,
                          paired = TRUE)
w_dgist_24h_1m
w_dgist_24h_1m$z_val#z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio


#item - gist memory change plot
p = ggboxplot(change_item_gist_error, x = "day", y = "errorChange", 
              color = "memoryType", facet.by = "memoryType") + #
  stat_compare_means(method = "wilcox.test", label = "p.signif", label.x = 1.4, paired = TRUE, size = 7)+ #, hide.ns = TRUE
  geom_point(position="jitter",aes(colour=factor(memoryType)), size = 1,shape = 21)+ # aes(fill = day), 
  labs(x = "Memory Type", y = "Error change after delay (pixels)")+
  scale_x_discrete(labels=c("24 hours", "1 ~ 2\n months"))+
  #title = "Error change of item and gist memory after 24 hours, 1 week and 1 ~ 2 months",  
  facet_grid(. ~ memoryType, labeller=labeller(memoryType = memoryTypeLabs))+
  scale_color_manual(breaks = c("dind", "dgist"),
                     values=c("palegreen3", "orchid"))+
  themeFacet

jpeg('Fig5_change_item_gist_eror_exp2.jpg', width = 3000, height =2000, units = 'px', res = 300)
p
dev.off()


# analysis 2: relation
shapiro.test(error_gists23$dindme)

lm_dgists <- lmer(dgist ~ dindme*day + (1|ID), data = error_gists23)
plot(lm_dgists)
anova(lm_dgists)
shapiro.test(residuals(lm_dgists))
qqnorm(residuals(lm_dgists))




##### bias analyses #####
##global bias#
#against 0 
shapiro.test(d1$globalBias)
shapiro.test(d2$globalBias)
shapiro.test(d3$globalBias)
t.test(d1$globalBias, mu = 0)
t.test(d2$globalBias, mu = 0)
t.test(d3$globalBias, mu = 0)

#session 2 vs. session 3 - change
shapiro.test(change_bias[change_bias$day == "Session 2",]$globalBias)
shapiro.test(change_bias[change_bias$day == "Session 3",]$globalBias)
t_gb_24h_1m=t.test(change_bias[change_bias$day == "Session 2",]$globalBias,change_bias[change_bias$day == "Session 3",]$globalBias,paired=TRUE)
t_gb_24h_1m



#boxplot
p_glb = ggboxplot(change_bias, x = "day", y = "globalBias") + #, color = "delay"
  ylim(-1, 1)+
  stat_compare_means(method = "t.test", label = "p.signif", label.x = 1.4, paired = TRUE, size = 7)+#hide.ns = TRUE, 
  geom_point(position = "jitter",size = 1, shape = 21)+
  labs(x = "Delay", y = "Global bias change after delay")+
  themeFacet

jpeg('Fig6a_change_biasGlobal_exp2.jpg', width = 2300, height =2300, units = 'px', res = 300)
p_glb
dev.off()

##local Bias##
#against 0 
shapiro.test(d1$localBias)
shapiro.test(d2$localBias)
shapiro.test(d3$localBias)
t.test(d1$localBias, mu = 0)
t.test(d2$localBias, mu = 0)
t.test(d3$localBias, mu = 0)

#session 2 vs. session 3 - change
shapiro.test(change_bias[change_bias$day == "Session 2",]$localBias)
shapiro.test(change_bias[change_bias$day == "Session 3",]$localBias)
t_lb_24h_1m=t.test(change_bias[change_bias$day == "Session 2",]$localBias,change_bias[change_bias$day == "Session 3",]$localBias,paired=TRUE)
t_lb_24h_1m

#boxplot
p_lcb = ggboxplot(change_bias, x = "day", y = "localBias") + #, color = "delay"
  ylim(-1, 1)+
  stat_compare_means(method = "t.test", label = "p.signif", label.x = 1.4, paired = TRUE, size = 7)+#hide.ns = TRUE, 
  geom_point(position = "jitter",size = 1, shape = 21)+
  labs(x = "Delay", y = "Local bias change after delay")+
  themeFacet

jpeg('Fig6b_change_biasLocal_exp2.jpg', width = 2300, height =2300, units = 'px', res = 300)
p_lcb
dev.off()

#outlier biased by local gist
shapiro.test(d2$outbyLocalGist -d1$outbyLocalGist)
shapiro.test(d3$outbyLocalGist -d1$outbyLocalGist)
source('wilcox_test.R')
w_outbylocalgist_24h_1m=wilcox.test(d2$outbyLocalGist -d1$outbyLocalGist,
                           d3$outbyLocalGist -d1$outbyLocalGist,
                           exact = FALSE,
                           paired = TRUE)
w_outbylocalgist_24h_1m
w_outbylocalgist_24h_1m$z_val


#Outlier weight
shapiro.test(opt_w1$optimal_weight)
shapiro.test(opt_w2$optimal_weight)
shapiro.test(opt_w3$optimal_weight)

t.test(opt_w1$optimal_weight, mu = 0.125)
t.test(opt_w2$optimal_weight, mu = 0.125)
t.test(opt_w3$optimal_weight, mu = 0.125)

t.test(opt_all$optimal_weight, mu = 0.125)

t.test(opt_w3$optimal_weight-opt_w1$optimal_weight,
       opt_w2$optimal_weight-opt_w1$optimal_weight,paired = TRUE)


###############supplementary materials###############

#supp5: outlier weight

comp_Session <- list(c("Session 1", "Session 2"), c("Session 1", "Session 3"), c("Session 2", "Session 3"))
p=ggboxplot(opt_all, x = "day", y = "optimal_weight") + #
  ylim(-.125, 0.75)+
  stat_compare_means(method = "anova", size = 7,  label = "p.signif", label.y =0.7)+#,hide.ns = TRUE
  stat_compare_means(comparisons = comp_Session,  label = "p.signif",method = "t.test", size = 6,paired=TRUE)+ #, hide.ns = TRUE
  geom_point(position="jitter", size = 1, shape = 21)+
  labs(y = "Estimated outlier weight")+
  scale_color_manual(name = "day", labels = c("after learning", "24 hours", "1 ~ 2 months"),
                     values=c("black","steelblue", "grey"))+
  scale_fill_manual(values=c("black","steelblue", "grey"),guide = 'none')+
  themeFacet
jpeg('Supp5_outlier_weight.jpg', width = 2700, height =2700,res = 300)
p
dev.off()

p = ggboxplot(dall_bias , x = "day", y = "bias", 
              facet.by = "biasType") + #
  stat_compare_means(method = "anova", size = 7,  label = "p.signif", paired=TRUE, label.y =1.26)+
  stat_compare_means(comparisons = list( c("1", "2"), c("1", "3"), c("2", "3")), label = "p.signif",
                     paired=TRUE, method = "t.test", size = 7)+ 
  geom_point(position="jitter",size = 1, shape = 21)+ 
  labs(x = "Memory Type", y = "Bias at each session")+
  facet_grid(. ~ biasType, labeller=labeller(biasType = biasTypeLabs ))+
  scale_x_discrete(labels=c("after\nlearning", "24 hours", "1 ~ 2\n months"))+
  themeFacet

jpeg('Supp6_bias.jpg', width = 3600, height =2400, units = 'px', res = 300)
p
dev.off()

model_global_bias = aov(bias ~ day + (1|ID),
            data = dall_bias[dall_bias$biasType =="globalBias",])
anova(model_global_bias)

model_local_bias = aov(bias ~ day + (1|ID),
                 data = dall_bias[dall_bias$biasType =="localBias",])
anova(model_local_bias)
