n_trials = 8;

megist = [mean(dotX(1:n_trials)), mean(dotY(1:n_trials))];

%gist chance performance: 
pdist2([720, 450],megist,'euclidean');
%223.9536

%ind chance performance: 

for i = 1: n_trials
        
    chance_ind(i) = pdist2([720, 450], [dotX(i), dotY(i)],'euclidean');
    
end

mean(chance_ind);
%386.6947
