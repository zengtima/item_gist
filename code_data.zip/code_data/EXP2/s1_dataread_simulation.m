 
n_trials = 8; 

n_o = 79;

n_sim = 1000; %number of simulations for baseline bias

cd stimuli_data;
load dot;
load out; 
cd ..;

%load gist_sti; previous wrong simulation

loc(:, 1) = dotX;
loc(:, 2) = dotY;

loc = sortrows(loc,1); %loc has to be sorted to fit into the simulation

%the criterion of excluding participants who misplaced outlier:
%Euclidean distance between the center of the screen and the encoded
%outlier location
outlier_range = pdist2(loc(1,:),[720, 450],'euclidean','Smallest',1);

%the coordinates of local center, the center of the encoded locations
%excluding the outlier;
local_center = mean(loc(2:n_trials,:));

%the coordinates of global center, the center of all encoded locations
megist = [mean(dotX), mean(dotY)];

% gist tested both on day1 and day 2
for s = 1:n_o
    
cd stimuli_data/participants;

    findday1 = dir([num2str(s) '_day1.mat']);
    findday2 = dir([num2str(s) '_day2.mat']);
    findday3 = dir([num2str(s) '_day3.mat']);
    
    if isempty(findday1) == 1 || isempty(findday2) == 1 || isempty(findday3) == 1
        ind3_dis = nan;
        ind3 = nan;
        gist3 = [nan, nan];
        gist3_dis = nan;
        day3_pay(s) = nan;
        

    sort1_o = [];
    dind1_sort_o(s,:) = nan;
    ind1_sort_o(:,1) = nan;
    ind1_sort_o(:,2) = nan;
    ind1X_sort_o(s,:) = nan;
    ind1Y_sort_o(s,:) = nan;

    dind_o(s,1) = nan;
    dinds1_o(s,:) = nan;
    dgist_o(s,1) = nan;        
  
    dindme_o(s,1) = nan;
    indme1_o(s,:) = nan;  
    
    sort2_o = [];
    dind2_sort_o(s,:) = nan;
    ind2_sort_o(:,1) = nan;
    ind2_sort_o(:,2) = nan;
    ind2X_sort_o(s,:) = nan;
    ind2Y_sort_o(s,:) = nan;

    dind_o(s,2) = nan;
    dinds2_o(s,:) = nan;
    dgist_o(s,2) = nan;
        
    dindme_o(s,2) = nan;
    indme2_o(s,:) = nan; 
    
    
    sort3_o = [];
    dind3_sort_o(s,:) = nan;
    ind3_sort_o(:,1) = nan;
    ind3_sort_o(:,2) = nan;
    ind3X_sort_o(s,:) = nan;
    ind3Y_sort_o(s,:) = nan;

    dind_o(s,3) = nan;
    dinds3_o(s,:) = nan;
    dgist_o(s,3) = nan;
  
    dindme_o(s,3) = nan;
    indme3_o(s,:) = nan;  
%
    
    disbias_inds1_o(s,:) = nan;
    disbias_inds2_o(s,:) = nan;
    disbias_inds3_o(s,:) = nan;
    
    disbias_o(s,:) = nan;
    
    sim_disbias_inds1_o(s,:) = nan;
    sim_disbias_inds2_o(s,:) = nan;
    sim_disbias_inds3_o(s,:) = nan;
    
    sim_disbias_o(s,:) = nan;
    
    
    lc_disbias_inds1_o(s,:) = nan;
    lc_disbias_inds2_o(s,:) = nan;
    lc_disbias_inds3_o(s,:) = nan;
    
    lc_disbias_o(s,:) = nan;
    
    sim_lc_disbias_inds1_o(s,:) = nan;
    sim_lc_disbias_inds2_o(s,:) = nan;
    sim_lc_disbias_inds3_o(s,:) = nan;
    
    sim_lc_disbias_o(s,:) = nan;
    
    cd ../..;

    
    else
        
    load([num2str(s) '_day1.mat']);
    load([num2str(s) '_day2.mat']);
    load([num2str(s) '_day3.mat']);
    
    cd ../..;

    
    %sort the responses to correspond with the encoded locations sorted
    %above, since the order of recalling the locations are randomized for each
    %participants
    
    sort1_o(:,1) = ind1_dis;
    sort1_o(:,2) = dotX(random_ind1);
    sort1_o(:,3) = dotY(random_ind1);
    sort1_o(:,4) = ind1(:,1);
    sort1_o(:,5) = ind1(:,2);
    [sort1_o, sort1_order] = sortrows(sort1_o,2);
    dind1_sort_o(s,:) = sort1_o(:,1);
    ind1_sort_o(:,1) = sort1_o(:,4);
    ind1_sort_o(:,2) = sort1_o(:,5);
    ind1X_sort_o(s,:) = sort1_o(:,4);
    ind1Y_sort_o(s,:) = sort1_o(:,5);

    sort2_o(:,1) = ind2_dis;
    sort2_o(:,2) = dotX(random_ind2);
    sort2_o(:,3) = dotY(random_ind2);
    sort2_o(:,4) = ind2(:,1);
    sort2_o(:,5) = ind2(:,2);
    [sort2_o, sort2_order] = sortrows(sort2_o,2);
    dind2_sort_o(s,:) = sort2_o(:,1);
    ind2_sort_o(:,1) = sort2_o(:,4);
    ind2_sort_o(:,2) = sort2_o(:,5);
    ind2X_sort_o(s,:) = sort2_o(:,4);
    ind2Y_sort_o(s,:) = sort2_o(:,5);

    sort3_o = [];
    sort3_o(:,1) = ind3_dis;
    sort3_o(:,2) = dotX(random_ind3);
    sort3_o(:,3) = dotY(random_ind3);
    sort3_o(:,4) = ind3(:,1);
    sort3_o(:,5) = ind3(:,2);
    [sort3_o, sort3_order] = sortrows(sort3_o,2);
    dind3_sort_o(s,:) = sort3_o(:,1);
    ind3_sort_o(:,1) = sort3_o(:,4);
    ind3_sort_o(:,2) = sort3_o(:,5);
    ind3X_sort_o(s,:) = sort3_o(:,4);
    ind3Y_sort_o(s,:) = sort3_o(:,5);

    %compute the item memory error for each subjects
    dind_o(s,1) = mean(ind1_dis);
    dind_o(s,2) = mean(ind2_dis);
    dind_o(s,3) = mean(ind3_dis);
    
    %the item memory error for each individual location
    dinds1_o(s,:) = ind1_dis;
    dinds2_o(s,:) = ind2_dis;
    dinds3_o(s,:) = ind3_dis;
    
    %record the gist memory error for each subjects which is calculated
    %during the test
    dgist_o(s,1) = gist1_dis;
    dgist_o(s,2) = gist2_dis;
    dgist_o(s,3) = gist3_dis;
    
    
    %compute estimated center error
    c_temp = mean(ind1)-megist;
    dindme_o(s,1) = sqrt(c_temp(1)^2 + c_temp(2)^2);
    indme1_o(s,:) = mean(ind1);
    
    c_temp = mean(ind2)-megist;
    dindme_o(s,2) = sqrt(c_temp(1)^2 + c_temp(2)^2);
    indme2_o(s,:) = mean(ind2);

    c_temp = mean(ind3)-megist;
    dindme_o(s,3) = sqrt(c_temp(1)^2 + c_temp(2)^2);
    indme3_o(s,:) = mean(ind3);

 
    %record reported center location
    gist1_o(s, 1:2) = gist1;
    gist2_o(s, 1:2) = gist2;
    gist3_o(s, 1:2) = gist3;

    %%bias analyses%%
    %absolute bias calculation

   
    [disbias_inds1_o(s, :), disbias_o(s,1)] = bias_func(loc, ind1_sort_o, gist1);

    [disbias_inds2_o(s, :), disbias_o(s,2)] = bias_func(loc, ind2_sort_o, gist2); 

    [disbias_inds3_o(s, :), disbias_o(s,3)] = bias_func(loc, ind3_sort_o, gist3);   

    
   %baseline bias by simulation
    [sim_disbias_inds1_o(s,:), sim_disbias_o(s,1)] ...
     = baseline_bias(loc, dind1_sort_o(s,:), gist1_o(s,:), n_sim, n_trials); 

    [sim_disbias_inds2_o(s,:), sim_disbias_o(s,2)] ...
     = baseline_bias(loc, dind2_sort_o(s,:), gist2_o(s,:), n_sim, n_trials); 

    [sim_disbias_inds3_o(s,:), sim_disbias_o(s,3)] ...
     = baseline_bias(loc, dind3_sort_o(s,:), gist3_o(s,:), n_sim, n_trials); 

    %Local Bias Analysis%

    [lc_disbias_inds1_o(s,:),lc_disbias_o(s,1)] = bias_func(loc, ind1_sort_o, local_center);
    [lc_disbias_inds2_o(s,:),lc_disbias_o(s,2)] = bias_func(loc, ind2_sort_o, local_center);
    [lc_disbias_inds3_o(s,:),lc_disbias_o(s,3)] = bias_func(loc, ind3_sort_o, local_center);

     
    %baseline of local bias by simulation
     [sim_lc_disbias_inds1_o(s,:), sim_lc_disbias_o(s,1)] ... 
     = baseline_bias(loc, dind1_sort_o(s,:), local_center, n_sim, n_trials); 

    [sim_lc_disbias_inds2_o(s,:), sim_lc_disbias_o(s,2)]... 
     = baseline_bias(loc, dind2_sort_o(s,:), local_center, n_sim, n_trials); 

    [sim_lc_disbias_inds3_o(s,:), sim_lc_disbias_o(s,3)]... 
     = baseline_bias(loc, dind3_sort_o(s,:), local_center, n_sim, n_trials); 
     
 
    end
    

end

%find the participants whose outlier response was out of range
[row_outwrong1, dontcare] = find(dind1_sort_o(:,1) > outlier_range);
[row_outwrong2, dontcare] = find(dind2_sort_o(:,1) > outlier_range);
[row_outwrong3, dontcare] = find(dind3_sort_o(:,1) > outlier_range);

ol_dgist_o1 = isoutlier(dgist_o(:,1), 'mean');
ol_dind_o1 = isoutlier(dind_o(:,1), 'mean');

ol_dgist_o2 = isoutlier(dgist_o(:,2), 'mean');
ol_dind_o2 = isoutlier(dind_o(:,2), 'mean');

ol_dgist_o3 = isoutlier(dgist_o(:,3), 'mean');
ol_dind_o3 = isoutlier(dind_o(:,3), 'mean');

dgist_o(ol_dgist_o1,:) = nan;
dgist_o(ol_dind_o1,:) = nan;
dgist_o(ol_dgist_o2,:) = nan;
dgist_o(ol_dind_o2,:) = nan;
dgist_o(ol_dgist_o3,:) = nan;
dgist_o(ol_dind_o3,:) = nan;

%exclude participants whose outlier response was out of range
dgist_o(row_outwrong1,:) = nan;
dgist_o(row_outwrong2,:) = nan;
dgist_o(row_outwrong3,:) = nan;

[row_dgist, dontcare] = find(isnan(dgist_o(:,1)) == 1);

%save data
cd s1_output;

label = {'ID';'day';'dind';'dgist'; 'dindme'; ...
    'disbias'; 'sim_disbias'; ...
'local_disbias'; 'sim_local_disbias'; ...
'outbygist'; 'sim_outbygist'};

%day 1
data1(:,1) = 1:n_o; %ID
data1(:,2) = 1;%day
data1(:,3) = dind_o(:,1); %item error
data1(:,4) = dgist_o(:,1); %center error
data1(:,5) = dindme_o(:,1); %estimated center error
data1(:,6) = disbias_o(:,1); %absolute global bias
data1(:,7) = sim_disbias_o(:,1); %baseline global bias
data1(:,8) = lc_disbias_o(:,1); %absolute local bias
data1(:,9) = sim_lc_disbias_o(:,1); %baseline local bias
data1(:,10) = lc_disbias_inds1_o(:,1); %absolute local bias - outlier
data1(:,11) = sim_lc_disbias_inds1_o(:,1); %baseline local bias - outlier

data1(row_dgist,:) = nan;

data1Table = array2table(data1,'VariableNames',label);
writetable(data1Table, 'out_data1.csv')


%day 2
data2(:,1) = 1:n_o; %ID
data2(:,2) = 2;%day
data2(:,3) = dind_o(:,2); %item error
data2(:,4) = dgist_o(:,2); %center error
data2(:,5) = dindme_o(:,2); %estimated center error
data2(:,6) = disbias_o(:,2); %absolute global bias
data2(:,7) = sim_disbias_o(:,2); %baseline global bias
data2(:,8) = lc_disbias_o(:,2); %absolute local bias
data2(:,9) = sim_lc_disbias_o(:,2); %baseline local bias
data2(:,10) = lc_disbias_inds2_o(:,1); %absolute local bias - outlier
data2(:,11) = sim_lc_disbias_inds2_o(:,1); %baseline local bias - outlier
 
data2(row_dgist,:) = nan;
 
data2Table = array2table(data2,'VariableNames',label);
writetable(data2Table, 'out_data2.csv')

%day 3
data3(:,1) = 1:n_o; %ID
data3(:,2) = 3;%day
data3(:,3) = dind_o(:,3); %item error
data3(:,4) = dgist_o(:,3); %center error
data3(:,5) = dindme_o(:,3); %estimated center error
data3(:,6) = disbias_o(:,3); %absolute global bias
data3(:,7) = sim_disbias_o(:,3); %baseline global bias
data3(:,8) = lc_disbias_o(:,3); %absolute local bias
data3(:,9) = sim_lc_disbias_o(:,3); %baseline local bias
data3(:,10) = lc_disbias_inds3_o(:,1); %absolute local bias - outlier
data3(:,11) = sim_lc_disbias_inds3_o(:,1); %baseline local bias - outlier
 
data3(row_dgist,:) = nan;
 
data3Table = array2table(data3,'VariableNames',label);
writetable(data3Table, 'out_data3.csv')

cd ..;