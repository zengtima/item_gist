library("tidyr")
#read in the d
d1 <- read_csv('out_data1.csv')
d2 <- read_csv('out_data2.csv')
d3 <- read_csv('out_data3.csv')
d1 <- na.omit(d1)
d2 <- na.omit(d2)
d3 <- na.omit(d3)


opt_w1 <- read_csv('out_w1.csv')
opt_w2 <- read_csv('out_w2.csv')
opt_w3 <- read_csv('out_w3.csv')

#exclude participants who were outliers
#the same way with data
opt_w1 <- opt_w1[opt_w1$ID %in% d1$ID, ]
opt_w2 <- opt_w2[opt_w2$ID %in% d1$ID, ]
opt_w3 <- opt_w3[opt_w3$ID %in% d1$ID, ]

opt_all = rbind(opt_w1, opt_w2, opt_w3)

opt_all$day <- factor(opt_all$day, levels = c(1, 2, 3))
opt_all$day <- ordered(opt_all$day, levels = 1:3,
                           labels = c("Session 1","Session 2", "Session 3")) #convert numeric to ordinal level

#item and gist error change
var_errors = c("ID", "day", "dind", "dgist")
change_item_gist_error = rbind(d2[var_errors],d3[var_errors])
change_item_gist_error[change_item_gist_error$day == 2,c("dind", "dgist")] = d2[c("dind", "dgist")] - d1[c("dind", "dgist")]
change_item_gist_error[change_item_gist_error$day == 3,c("dind", "dgist")] = d3[c("dind", "dgist")] - d1[c("dind", "dgist")]

memoryTypeLabs <- c(dind="Item", dgist="Center (Gist)") 
change_item_gist_error = melt(change_item_gist_error, id.vars = c("ID", "day"))
change_item_gist_error = rename(change_item_gist_error, c("value"="errorChange", "variable"="memoryType"))
change_item_gist_error$day<- factor(change_item_gist_error$day, levels = c(2, 3))

dind_chance = 387
dgist_chance = 224

#gist and estiamted gist error
var_gists_error = c("ID", "day", "dgist", "dindme")
error_gists23 = rbind(d2[var_gists_error],d3[var_gists_error])
error_gists23$day <- ordered(error_gists23$day, levels = 2:3,
                              labels = c("Session 2", "Session 3")) #convert numeric to ordinal level

#bias change compared to baseline simulation#
#compared to baseline
d1["globalBias"] = d1["disbias"] - d1["sim_disbias"]
d2["globalBias"] = d2["disbias"] - d2["sim_disbias"]
d3["globalBias"] = d3["disbias"] - d3["sim_disbias"]

d1["localBias"] = d1["local_disbias"] - d1["sim_local_disbias"]
d2["localBias"] = d2["local_disbias"] - d2["sim_local_disbias"]
d3["localBias"] = d3["local_disbias"] - d3["sim_local_disbias"]

d1["outbyLocalGist"] = d1["outbygist"] - d1["sim_outbygist"]
d2["outbyLocalGist"] = d2["outbygist"] - d2["sim_outbygist"]
d3["outbyLocalGist"] = d3["outbygist"] - d3["sim_outbygist"]


#bias change
var_bias = c("ID", "day", "globalBias", "localBias")
change_bias = rbind(d2[var_bias],d3[var_bias])
change_bias[change_bias$day == 2,c("globalBias", "localBias")] = d2[c("globalBias", "localBias")] - d1[c("globalBias", "localBias")]
change_bias[change_bias$day == 3,c("globalBias", "localBias")] = d3[c("globalBias", "localBias")] - d1[c("globalBias", "localBias")]

change_bias$day <- factor(change_bias$day, levels = c(2, 3))
change_bias$day <- ordered(change_bias$day, levels = 2:3,
                       labels = c("Session 2", "Session 3")) #convert numeric to ordinal level


change_bias$day <- ordered(change_bias$day, levels = 2:3,
                          labels = c("Session 2", "Session 3")) #convert numeric to ordinal level

change_bias$day <- ordered(change_bias$day, levels = 2:3,
                           labels = c("Session 2", "Session 3")) #convert numeric to ordinal level

#outlier: bias change
var_out_bias = c("ID", "day", "outbyLocalGist")
out_change_bias = rbind(d2[var_out_bias],d3[var_out_bias])
out_change_bias[out_change_bias$day == 2,"outbyLocalGist"] = d2["outbyLocalGist"] - d1["outbyLocalGist"]
out_change_bias[out_change_bias$day == 3,"outbyLocalGist"] = d3["outbyLocalGist"] - d1["outbyLocalGist"]


#supplementary
dall = rbind(d1,d2,d3)

dall_error = dall[var_errors] 
dall_error = melt(dall_error, id.vars = c("ID", "day"))
dall_error = rename(dall_error, c("value"="error", "variable"="memoryType"))
dall_error$day<- factor(dall_error$day, levels = c(1, 2, 3))
dall_error$chance <- ifelse(dall_error$memoryType == "dind", dind_chance, dgist_chance)

biasTypeLabs <- c(globalBias="Global bias", localBias="Local bias") 
dall_bias= dall[var_bias] 
dall_bias = melt(dall_bias, id.vars = c("ID", "day"))
dall_bias = rename(dall_bias, c("value"="bias", "variable"="biasType"))
dall_bias$day<- factor(dall_bias$day, levels = c(1, 2, 3))


#themes
themeFacet = theme(title = element_text(color = "black", size = 20, face = "plain"),
                   plot.title = element_text(hjust = 0.5),
                   axis.title = element_text(color = "black", size = 25, angle = 90, hjust = 1, vjust = .5, face = "plain"),
                   axis.text.x = element_text(color = "black", size = 25, angle = 0, hjust = .5, vjust = .5, face = "plain"),
                   axis.text.y = element_text(color = "black", size = 25, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
                   axis.title.x = element_blank(),
                   axis.title.y = element_text(color = "black", size = 25, angle = 90, hjust = .5, vjust = .5, face = "plain"),
                   strip.text.x = element_text(size = 30, colour = "black"),
                   strip.background = element_blank(),
                   axis.ticks = element_blank(),
                   panel.border = element_blank(), 
                   panel.grid.major = element_blank(),
                   panel.grid.minor = element_blank(), 
                   legend.position='none')
