if(!require(MASS)){install.packages('MASS')}
if(!require(R.matlab)){install.packages('R.matlab')}
if(!require(ggplot2)){install.packages('ggplot2')}
if(!require(magrittr)){install.packages('magrittr')}
if(!require(ggpubr)){install.packages('ggpubr')}
if(!require(psych)){install.packages('psych')}
if(!require(Hmisc)){install.packages('Hmisc')}
if(!require(readr)){install.packages('readr')}
if(!require(plyr)){install.packages('plyr')}
if(!require(readr)){install.packages('readr')}
if(!require(reshape2)){install.packages('reshape2')}

if(!require(mblm)){install.packages('mblm')}
if(!require(quantreg)){install.packages('quantreg')}
if(!require(rcompanion)){install.packages('rcompanion')}
if(!require(mgcv)){install.packages('mgcv')}
if(!require(lmtest)){install.packages('lmtest')}
if(!require(lmerTest)){install.packages('lmerTest')}

if(!require(ARTool)){install.packages('ARTool')}
if(!require(emmeans)){install.packages('emmeans')}
if(!require(interactions)){install.packages('interactions')}

library('MASS')
library('R.matlab')
library('ggplot2')
library('magrittr')
library('ggpubr')
library('psych')
library('Hmisc')
library('readr')
library("plyr")
library('reshape2')

library('mblm')
library('quantreg')
library('rcompanion')
library('mgcv')
library('lmtest')
library('lmerTest')

library('ARTool')
library('emmeans')
library('interactions')

#you need to set the working directory to be code_data/EXP1
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

source('read_data.R')


###### Error Analysis #####
#the change of item and gist error
shapiro.test(as.numeric(dchange_error[dchange_error$memoryType == "dind" ,"errorChange"]))
shapiro.test(as.numeric(dchange_error[dchange_error$memoryType == "dgist" ,"errorChange"]))

model = art(errorChange ~ group + memoryType + group:memoryType,
            data = dchange_error)
anova(model)

#dind against chance
wilcox.test(d24h1$dind, mu = dind_chance, exact = FALSE)
wilcox.test(d1w1$dind, mu = dind_chance, exact = FALSE)
wilcox.test(d1m1$dind, mu = dind_chance, exact = FALSE)

wilcox.test(d24h2$dind, mu = dind_chance, exact = FALSE)
wilcox.test(d1w2$dind, mu = dind_chance, exact = FALSE)
wilcox.test(d1m2$dind, mu = dind_chance, exact = FALSE)

#reported gist against chance
wilcox.test(d24h1$dgist, mu = dgist_chance, exact = FALSE)
wilcox.test(d1w1$dgist, mu = dgist_chance, exact = FALSE)
wilcox.test(d1m1$dgist, mu = dgist_chance, exact = FALSE)

wilcox.test(d24h2$dgist, mu = dgist_chance, exact = FALSE)
wilcox.test(d1w2$dgist, mu = dgist_chance, exact = FALSE)
wilcox.test(d1m2$dgist, mu = dgist_chance, exact = FALSE)


#item memory pairwise comparisons: all significant
w_dind_24h_1w=wilcox.test(dchange_error[dchange_error$memoryType == "dind" & dchange_error$group == "24 hours","errorChange"],
                          dchange_error[dchange_error$memoryType == "dind" & dchange_error$group == "1 week","errorChange"],
                          exact = FALSE)
w_dind_24h_1w
w_dind_24h_1w$z_val #z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio

w_dind_1w_1m=wilcox.test(dchange_error[dchange_error$memoryType == "dind" & dchange_error$group == "1 week","errorChange"],
                          dchange_error[dchange_error$memoryType == "dind" & dchange_error$group == "1 month","errorChange"],
                          exact = FALSE)
w_dind_1w_1m
w_dind_1w_1m$z_val #z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio

w_dind_24h_1m=wilcox.test(dchange_error[dchange_error$memoryType == "dind" & dchange_error$group == "24 hours","errorChange"],
                          dchange_error[dchange_error$memoryType == "dind" & dchange_error$group == "1 month","errorChange"],
                          exact = FALSE)
w_dind_24h_1m
w_dind_24h_1m$z_val #z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio



#gist memory pairwise comparisons:
w_dgist_24h_1w=wilcox.test(dchange_error[dchange_error$memoryType == "dgist" & dchange_error$group == "24 hours","errorChange"],
                          dchange_error[dchange_error$memoryType == "dgist" & dchange_error$group == "1 week","errorChange"],
                          exact = FALSE)
w_dgist_24h_1w
w_dgist_24h_1w$z_val #z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio

w_dgist_1w_1m=wilcox.test(dchange_error[dchange_error$memoryType == "dgist" & dchange_error$group == "1 week","errorChange"],
                         dchange_error[dchange_error$memoryType == "dgist" & dchange_error$group == "1 month","errorChange"],
                         exact = FALSE)
w_dgist_1w_1m
w_dgist_1w_1m$z_val #z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio


w_dgist_24h_1m=wilcox.test(dchange_error[dchange_error$memoryType == "dgist" & dchange_error$group == "24 hours","errorChange"],
                          dchange_error[dchange_error$memoryType == "dgist" & dchange_error$group == "1 month","errorChange"],
                          exact = FALSE)
w_dgist_24h_1m
w_dgist_24h_1m$z_val #z_val in the paper was computed by running source('wilcox_test.R'), which you can also try, 
#but this way the zstats in the plots may not be able to be generated, in that case you will need to restart rstudio


#item - gist memory change plot
p = ggboxplot(dchange_error, x = "group", y = "errorChange", 
              color = "memoryType", facet.by = "memoryType") + #
  stat_compare_means(comparisons = my_comparisons, method = "wilcox.test", label = "p.signif", size = 7)+ 
  geom_point(position="jitter",aes(colour=factor(memoryType)), size = 1,shape = 21)+ 
  labs(x = "Memory Type", y = "Error change after delay (pixels)")+
  scale_x_discrete(labels=c("24 hours", "1 week", "1 month"))+
  #title = "Error change of item and gist memory after 24 hours, 1 week and 1 ~ 2 months",  
  facet_grid(. ~ memoryType, labeller=labeller(memoryType = memoryTypeLabs))+
  scale_color_manual(breaks = c("dind", "dgist"),
                     values=c("palegreen3", "orchid"))+
  themeFacet

jpeg('Fig2b_change_item_gist_eror_exp1.jpg', width = 3000, height =2000, units = 'px', res = 300)
p
dev.off()


# analysis 2: relation
shapiro.test(d2$dindme)
lm_dgists <- lm(dgist ~ dindme*group, data = d2)
plot(lm_dgists)
anova(lm_dgists)
shapiro.test(residuals(lm_dgists))
qqnorm(residuals(lm_dgists))



##### bias analyses #####
#against 0 
#session 1: none of the below significantly different than 0
shapiro.test(d24h1$bias)
shapiro.test(d1w1$bias)
shapiro.test(d1m1$bias)
t.test(d24h1$bias, mu = 0)
t.test(d1w1$bias, mu = 0)
t.test(d1m1$bias, mu = 0)

#session 2: only 1 month significantly higher than 0
shapiro.test(d24h2$bias)
shapiro.test(d1w2$bias)
shapiro.test(d1m2$bias)
t.test(d24h2$bias, mu = 0)
t.test(d1w2$bias, mu = 0)
t.test(d1m2$bias, mu = 0)

#session 1 vs. session 2 - change - between group comparison
shapiro.test(dchange_bias[dchange_bias$group == "24 hours",]$bias)
shapiro.test(dchange_bias[dchange_bias$group == "1 week",]$bias)
shapiro.test(dchange_bias[dchange_bias$group == "1 month",]$bias)

anova_biasChange=aov(bias ~ group, data=dchange_bias)
summary(anova_biasChange)

t_bias_24h_1w=t.test(dchange_bias[dchange_bias$group == "24 hours",]$bias,dchange_bias[dchange_bias$group == "1 week",]$bias)
t_bias_24h_1w

t_bias_24h_1m=t.test(dchange_bias[dchange_bias$group == "24 hours",]$bias,dchange_bias[dchange_bias$group == "1 month",]$bias)
t_bias_24h_1m

t_bias_1w_1m=t.test(dchange_bias[dchange_bias$group == "1 week",]$bias,dchange_bias[dchange_bias$group == "1 month",]$bias)
t_bias_1w_1m

#boxplot
p_bias = ggboxplot(dchange_bias, x = "group", y = "bias") + #, color = "delay"
  ylim(-1, 1.7)+
  stat_compare_means(comparisons = my_comparisons,method = "t.test", label = "p.signif",label.y = c(1.2, 1.4, 1.6), size = 7)+#hide.ns = TRUE, 
  geom_point(position = "jitter",size = 1, shape = 21)+
  labs(y = "Bias change after delay\n (between session 1 and 2)")+
  themeFacet

jpeg('Fig3b_change_bias_exp1.jpg', width = 2300, height =2300, units = 'px', res = 300)
p_bias
dev.off()

#bias analysis using the center of encoded items
t.test(d24h2$bias_hcm, mu = 0)
t.test(d1w2$bias_hcm, mu = 0)
t.test(d1m2$bias_hcm, mu = 0)

anova_bias_hcm=aov(bias_hcm ~ group, data=dchange_bias)
summary(anova_bias_hcm)

### supplementary materials ###
#1
p = ggboxplot(d1_errors, x = "group", y = "error", 
              color = "memoryType", facet.by = "memoryType") + #
  stat_compare_means(comparisons = my_comparisons, label = "p.signif",
                     method = "t.test", size = 7, label.y = c(250, 280, 310))+ #, hide.ns = TRUE
  stat_compare_means(method = "anova", label.y = 300, size = 7, label = "p.signif")+#, hide.ns = TRUE
  geom_hline(aes(yintercept=chance),colour="red", linetype="dashed")+
  geom_point(position="jitter",aes(colour=factor(memoryType)), size = 1, shape = 21)+ #
  labs(x = "Memory Type", y = "Error at Session 1 (pixels)")+
  facet_grid(. ~ memoryType, labeller=labeller(memoryType = memoryTypeLabs ))+
  scale_color_manual(breaks = c("indchange", "gistchange"),
                     values=c("palegreen3", "orchid"))+
  scale_x_discrete(labels=c("24 hour","1 week", "1 month")) +
  themeFacet

jpeg('supp1_item_gist_ses1.jpg', width = 3600, height =2400, units = 'px', res = 300)
p
dev.off()

#2
p = ggboxplot(d2_errors, x = "group", y = "error", 
              color = "memoryType", facet.by = "memoryType") + #
  stat_compare_means(comparisons = my_comparisons, label = "p.signif",
                     method = "t.test", size = 7, label.y = c(460, 490, 530))+ #, hide.ns = TRUE
  stat_compare_means(method = "anova", label.y = 530, size = 7, label = "p.signif")+#, hide.ns = TRUE
  geom_hline(aes(yintercept=chance),colour="red", linetype="dashed")+
  geom_point(position="jitter",aes(colour=factor(memoryType)), size = 1, shape = 21)+ #
  labs(x = "Memory Type", y = "Error at Session 2 (pixels)")+
  facet_grid(. ~ memoryType, labeller=labeller(memoryType = memoryTypeLabs ))+
  scale_color_manual(breaks = c("indchange", "gistchange"),
                     values=c("palegreen3", "orchid"))+
  scale_x_discrete(labels=c("24 hour","1 week", "1 month")) +
  themeFacet

jpeg('supp2_item_gist_ses2.jpg', width = 3600, height =2400, units = 'px', res = 300)
p
dev.off()


#bias
p = ggboxplot(dall, x = "group", y = "bias", 
              facet.by = "day") + #
  stat_compare_means(label = "p.signif", label.x.npc = "left", label.y = 1.4,size = 7)+ #, hide.ns = TRUE
  stat_compare_means(comparisons = my_comparisons, label = "p.signif", label.x.npc = "center", size = 7)+ #, hide.ns = TRUE
   geom_point(position="jitter",size = 1, shape = 21)+
  facet_grid(. ~ day, labeller=labeller(day = c('1'="Session 1", '2'="Session 2")))+
  labs(y = "Bias")+
  #facet_grid(. ~ day, labeller=labeller(day = groupLabs))+
  #scale_x_discrete(labels=c("Session 1","Session 2")) +
  themeFacet

jpeg('supp3_bias.jpg', width = 4320, height =2470, units = 'px', res = 300)
p
dev.off()

p = ggboxplot(dall, x = "group", y = "bias_hcm", 
              facet.by = "day") + #
  stat_compare_means(comparisons = my_comparisons, label = "p.signif", label.x.npc = "center", size = 7)+ #, hide.ns = TRUE
  #geom_hline(yintercept=555, colour="darkturquoise", linetype="dashed")+
  geom_point(position="jitter",size = 1, shape = 21)+
  labs(y = "bias")+
  #facet_grid(. ~ day, labeller=labeller(day = groupLabs))+
  #scale_x_discrete(labels=c("Session 1","Session 2")) +
  themeFacet

jpeg('supp_bias_hcm.jpg', width = 4320, height =2470, units = 'px', res = 300)
p
dev.off()

aov_bias <- aov(bias ~ group*day, data = dall)
# Summary of the analysis
summary(aov_bias)

