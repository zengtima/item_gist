
for cs1w = 1:25

load([num2str(cs1w) '_day1.mat']);
    
n_trials = 6;

for i = 1: n_trials
    for ii = 1:n_trials
        c_temp1 = ind2(i, 1) - dotX(ii);
        c_temp2 = ind2(i, 2) - dotY(ii);
        c_temp = sqrt(c_temp1^2 + c_temp2^2);
        temp_mat1(i, ii) = c_temp;
        
    end
end


for i = 1: n_trials

    ind_temp = find(temp_mat1(i, :) == ind2_dis(i));
    random_ind2(i) = ind_temp;

end

save('random_ind2', 'random_ind2');
save('current subject', 'cs1w');
clear;

load('current subject');

load([num2str(cs1w) '_day1.mat']);

load('random_ind2');
save([num2str(cs1w) '_day1.mat']);
clear;

end
