 
n_trials = 6; 

n_s =56;
n_sim = 1000;
n_start = 1;

load lt_v3;

loc(:,1) = dotX;
loc(:,2) = dotY;


load ltv3_1w_age_gen;

megist = [mean(dotX(1:n_trials)), mean(dotY(1:n_trials))];
gistlearn = dinds_me(dotX, dotY);
indlearn = 186.5;

% gist tested both on day1 and day 2
for s = n_start:n_s
   
cd lt_v3_1w;    

if isfile([num2str(s) '_day2.mat'])  && (age_gender_1w(s,1) <= 30)
     % File exists.
     

    load([num2str(s) '_day1.mat']);
    load([num2str(s) '_day2.mat']);
    
cd ..;
    
    dgist_ceil_1w(s) = gist_ceil_dis;
    
    %note that that hear ind2s are individual memory of the first day
%and ind3s are ind memory for the second session
dind_1w(s,1) = mean(ind2_dis);
dind_1w(s,2) = mean(ind3_dis);

dinds1_1w(s,:) = ind2_dis;
dinds2_1w(s,:) = ind3_dis;

dgist_1w(s,1) = gist1_dis;
dgist_1w(s,2) = gist2_dis;

%distance between the center of inds and gist 
c_temp = mean(ind2)-gist1;
dindcg_1w(s,1) = sqrt(c_temp(1)^2 + c_temp(2)^2);
c_temp = mean(ind3)-gist2;
dindcg_1w(s,2) = sqrt(c_temp(1)^2 + c_temp(2)^2);


%distance between each of inds and gist (2 because without labels)
for i = 1: n_trials

c_temp = ind2(i,:)-gist1;
dindg2_temp1(i) = sqrt(c_temp(1)^2 + c_temp(2)^2);

c_temp = ind3(i,:)-gist2;
dindg2_temp2(i) = sqrt(c_temp(1)^2 + c_temp(2)^2);

end

%mean distance between each ind and gist
dindg_1w(s,1) = nanmean(dindg2_temp1);
dindg_1w(s,2) = nanmean(dindg2_temp2);


gist1_1w(s, 1:2) = gist1;
gist2_1w(s, 1:2) = gist2;

ind1X_1w(s, :) = ind2(:,1);
ind1Y_1w(s, :) = ind2(:,2);

dotX_1w(s, :) = dotX;
dotY_1w(s, :) = dotY;

ind2X_1w(s, :) = ind3(:,1);
ind2Y_1w(s, :) = ind3(:,2);

random_order2_1w(s,:) = random_ind2;
random_order3_1w(s,:) = random_ind3;

%distance between the center of inds and real mean
c_temp = mean(ind2)-megist;
dindme_1w(s,1) = sqrt(c_temp(1)^2 + c_temp(2)^2);
c_temp = mean(ind3)-megist;
dindme_1w(s,2) = sqrt(c_temp(1)^2 + c_temp(2)^2);


%ignore label individual
%step1: create distance matrix
for i = 1: n_trials
    for ii = 1:n_trials
        c_temp1 = ind2(i, 1) - dotX(ii);
        c_temp2 = ind2(i, 2) - dotY(ii);
        c_temp = sqrt(c_temp1^2 + c_temp2^2);
        temp_mat1(i, ii) = c_temp;
        
        
        c_temp1 = ind3(i, 1) - dotX(ii);
        c_temp2 = ind3(i, 2) - dotY(ii);
        c_temp = sqrt(c_temp1^2 + c_temp2^2);
        temp_mat2(i, ii) = c_temp;
        
    end
end


%step2: find the one and only one for dot ii (real location)

    for ii = 1: n_trials
 
        %day 1
            od_temp = find(temp_mat1(:, ii) == min(temp_mat1(:, ii)));
            
            if min(temp_mat1(od_temp, :)) == min(temp_mat1(:, ii))
               ind_min1_1w(s,ii) = min(temp_mat1(:, ii));
               %for retrieval i, the associated encoded location is dot ii
               ind_min_order1_1w(s,ii) = od_temp;
               ind_min_retX1_1w(s,ii) = ind2(od_temp, 1);
               ind_min_retY1_1w(s,ii) = ind2(od_temp, 2);
               temp_mat1(od_temp, :) = nan;
            else %for recall i, its closest encoded location ii 
               ind_min1_1w(s,ii) = nan;
               ind_min_order1_1w(s,ii) = nan;
               ind_min_retX1_1w(s,ii) = nan;
               ind_min_retY1_1w(s,ii) = nan;
            end
           
        %day 2
            od_temp = find(temp_mat2(:, ii) == min(temp_mat2(:, ii)));
            
            if min(temp_mat2(od_temp, :)) == min(temp_mat2(:, ii))
               ind_min2_1w(s,ii) = min(temp_mat2(:, ii));
               %for retrieval i, the associated encoded location is dot ii
               ind_min_order2_1w(s,ii) = od_temp;
               ind_min_retX2_1w(s,ii) = ind3(od_temp, 1);
               ind_min_retY2_1w(s,ii) = ind3(od_temp, 2);
               temp_mat2(od_temp, :) = nan;
            else %for recall i, its closest encoded location ii 
               ind_min2_1w(s,ii) = nan;
               ind_min_order2_1w(s,ii) = nan;
               ind_min_retX2_1w(s,ii) = nan;
               ind_min_retY2_1w(s,ii) = nan;
            end
 
    end
    
    
    notlabel_1w(s,1) = length(find(isnan(ind_min1_1w(s,:))));
    notlabel_1w(s,2) = length(find(isnan(ind_min2_1w(s,:))));
 
    
 dind_min_1w(s,1) = nanmean(ind_min1_1w(s,:))*(notlabel_1w(s,1)+1);   
 dind_min_1w(s,2) = nanmean(ind_min2_1w(s,:))*(notlabel_1w(s,2)+1);   
    
%new ind biased by gist measurement
for i = 1:n_trials
P0 = [dotX(random_ind2(i)), dotY(random_ind2(i))];
P1 = [gist1(1,1), gist1(1,2)];
P2 = [ind2(i,1), ind2(i,2)];
n1 = (P2 - P0) / norm(P2 - P0);  % Normalized vectors
n2 = (P1 - P0) / norm(P1 - P0);
%angle1(s,i) = acos(dot(n1, n2));                        % Instable at (anti-)parallel n1 and n2
angle1(s,i) = dot(n1, n2);  

enc_ret = sqrt((dotX(random_ind2(i))-ind2(i,1)).^2 + (dotY(random_ind2(i))-ind2(i,2)).^2); 
enc_cen = sqrt((dotX(random_ind2(i))-gist1(1,1)).^2   + (dotY(random_ind2(i))-gist1(1,2)).^2); 
ret_cen = sqrt((ind2(i,1)-gist1(1,1)).^2 + (ind2(i,2)-gist1(1,2)).^2); 

disbias_inds1_1w(s, i) = (enc_cen - ret_cen)/enc_ret;

%angleBias_ret{dst_i,s}(i)=acosd((enc_ret.^2+enc_cen^2-ret_cen.^2)./(2*enc_ret*enc_cen));   
%angleBias_enc{dst_i,s}(i)=acosd((enc_ret.^2+ret_cen.^2-enc_cen^2)./(2*enc_ret.*ret_cen));   
   

%%bhattacharyya distance
bd_1w(s,1) = bhattacharyya(loc, ind2);
bd_1w(s,2) = bhattacharyya(loc, ind3);

% one trial
angleBias_enc1(s,i)=acosd((enc_ret.^2+enc_cen^2-ret_cen.^2)./(2*enc_ret*enc_cen));   


P0 = [dotX(random_ind3(i)), dotY(random_ind3(i))];
P1 = [gist2(1,1), gist2(1,2)];
P2 = [ind3(i,1), ind3(i,2)];
n1 = (P2 - P0) / norm(P2 - P0);  % Normalized vectors
n2 = (P1 - P0) / norm(P1 - P0);
%angle2(s,i) = acos(dot(n1, n2));  
angle2(s,i) = dot(n1, n2);  

enc_ret = sqrt((dotX(random_ind3(i))-ind3(i,1)).^2 + (dotY(random_ind3(i))-ind3(i,2)).^2); 
enc_cen = sqrt((dotX(random_ind3(i))-gist2(1,1)).^2   + (dotY(random_ind3(i))-gist2(1,2)).^2); 
ret_cen = sqrt((ind3(i,1)-gist2(1,1)).^2 + (ind3(i,2)-gist2(1,2)).^2); 

angleBias_enc2(s,i)=acosd((enc_ret.^2+enc_cen^2-ret_cen.^2)./(2*enc_ret*enc_cen));   
disbias_inds2_1w(s, i) = (enc_cen - ret_cen)/enc_ret;

end

bias_angle_1w(s,1) = nanmean(angle1(s,:));
bias_angle_1w(s,2) = nanmean(angle2(s,:));

bias_angle2_1w(s,1) = nanmean(angleBias_enc1(s,:));
bias_angle2_1w(s,2) = nanmean(angleBias_enc2(s,:));

disbias_1w(s,1) = nanmean(disbias_inds1_1w(s,:));
disbias_1w(s,2) = nanmean(disbias_inds2_1w(s,:));

enc_ret = sqrt((megist(1,1)-gist1_1w(s,1)).^2 + (megist(1,2)-gist1_1w(s,2)).^2); 
enc_cen = sqrt((megist(1,1)-mean(ind2(:,1))).^2 + (megist(1,2)-mean(ind2(:,2))).^2); 
ret_cen = sqrt((gist1_1w(s,1)-mean(ind2(:,1))).^2 + (gist1_1w(s,2)-mean(ind2(:,2))).^2); 
 
bias_g_indc_1w(s,1)=acosd((enc_ret.^2+enc_cen^2-ret_cen.^2)./(2*enc_ret*enc_cen));   
 
enc_ret = sqrt((megist(1,1)-gist2_1w(s,1)).^2 + (megist(1,2)-gist2_1w(s,2)).^2); 
enc_cen = sqrt((megist(1,1)-mean(ind3(:,1))).^2 + (megist(1,2)-mean(ind3(:,2))).^2); 
ret_cen = sqrt((gist2_1w(s,1)-mean(ind3(:,1))).^2 + (gist2_1w(s,2)-mean(ind3(:,2))).^2); 
 
bias_g_indc_1w(s,2)=acosd((enc_ret.^2+enc_cen^2-ret_cen.^2)./(2*enc_ret*enc_cen));   

else
     % File does not exist.
    dgist_1w(s,:) = nan;
    bias_angle2_1w(s,:) = nan;
    dind_1w(s,:) = nan;
    
    dindcg_1w(s,:) = nan; 
    dindme_1w(s,:) = nan; 
    dindg_1w(s,:) = nan; 
    dgist_ceil_1w(s) = nan;

    angle1(s,1:6) = nan;
    angle2(s,1:6) = nan;
    
    angleBias_enc1(s,1:6) = nan;
    angleBias_enc2(s,1:6) = nan;
    
    disbias_inds1_1w(s,:) = nan;
    disbias_inds2_1w(s,:) = nan;
    %disbias_inds_1w(s,1:2) = nan;
    
ind1X_1w(s, :) = nan;
ind1Y_1w(s, :) = nan;

dinds1_1w(s, :) = nan;
dinds2_1w(s, :) = nan;

ind2X_1w(s, :) = nan;
ind2Y_1w(s, :) = nan;

dotX_1w(s, :) = nan;
dotY_1w(s, :) = nan;

random_order2_1w(s,:) = nan;
random_order3_1w(s,:) = nan;

    ind_min1_1w(s,:) = nan;
    ind_min_order1_1w(s,:) = nan;
    ind_min2_1w(s,:) = nan;
    ind_min_order2_1w(s,:) = nan;
    
    dind_min_1w(s,:) = nan;
    
bd_1w(s,:) = nan;

    cd ..;

end    


end


%dgist
notlearngist = find(dgist_1w(:,1) >= gistlearn);
%notlearngist2 = find(dgist_1w(:,2) >= gistlearn);
dgist_1w(notlearngist, :) = nan;
%dgist_1w(notlearngist2, :) = nan;


%ol_dgist_1w = isoutlier(dgist_1w, 'mean');
%ol_dind_nolabel_1w = isoutlier(dind_nolabel_1w, 'mean');

%dgist_1w(ol_dind_nolabel_1w) = nan;
%dgist_1w(ol_dgist_1w) = nan;

[row_dgist, dontcare] = find((isnan(dgist_1w) == 1));

dgist_1w(row_dgist,:) = nan;
disbias_1w(row_dgist,:) = nan;

bias_angle_1w(row_dgist,:) = nan;
bias_angle2_1w(row_dgist,:) = nan;

angle1(row_dgist,:) = nan;
angle2(row_dgist,:) = nan;

angleBias_enc1(row_dgist,:) = nan;
angleBias_enc2(row_dgist,:) = nan;

disbias_inds1_1w(row_dgist,:) = nan;
disbias_inds2_1w(row_dgist,:) = nan;
    
dind_1w(row_dgist,:) = nan;
dind_nolabel_1w(row_dgist,:) = nan;
dindcg_1w(row_dgist,:) = nan; 
dindme_1w(row_dgist,:) = nan; 
dindg_1w(row_dgist,:) = nan; 
dgist_ceil_1w(row_dgist) = nan; 

dind_min_1w(row_dgist,:) = nan;

dinds1_1w(row_dgist,:) = nan; 
dinds2_1w(row_dgist,:) = nan; 

gist1_1w(row_dgist,:) = nan;
gist2_1w(row_dgist,:) = nan;

ind1X_1w(row_dgist, :) = nan;
ind1Y_1w(row_dgist, :) = nan;

ind2X_1w(row_dgist, :) = nan;
ind2Y_1w(row_dgist, :) = nan;

dotX_1w(row_dgist, :) = nan;
dotY_1w(row_dgist, :) = nan;

bias_g_indc_1w(row_dgist, :) = nan;

random_order2_1w(row_dgist, :) = nan;
random_order3_1w(row_dgist, :) = nan;

ind_min1_1w(row_dgist, :) = nan;
ind_min_order1_1w(row_dgist, :) = nan;
ind_min2_1w(row_dgist, :) = nan;
ind_min_order2_1w(row_dgist, :) = nan;

ind_min_retX1_1w(row_dgist, :) = nan;
ind_min_retY1_1w(row_dgist, :) = nan;
ind_min_retX2_1w(row_dgist, :) = nan;
ind_min_retY2_1w(row_dgist, :) = nan;

bd_1w(row_dgist, :) = nan;

bias_inds_1w(:,1) = reshape(angle1',[],1);
bias_inds_1w(:,2) = reshape(angle2',[],1);

bias_inds2_1w(:,1) = reshape(angleBias_enc1',[],1);
bias_inds2_1w(:,2) = reshape(angleBias_enc2',[],1);

disbias_inds_1w(:,1) = reshape(disbias_inds1_1w',[],1);
disbias_inds_1w(:,2) = reshape(disbias_inds2_1w',[],1);


bd_1w(row_dgist, :) = nan;
%Bias simulation
for i = n_start:n_s

    if isnan(dgist_1w(i, 2))
        sim_dindcg_1w(i,1) = nan;
        sim_dindcg_1w(i,2) = nan;
        sim_dindcg_rely_1w(i,1) = nan;
        sim_dindcg_rely_1w(i,2) = nan;
        sim_bias_inds_avg_1w(i,1:2)= nan;
        sim_bias_inds1_1w(i,1:n_trials)=nan;
        sim_bias_inds2_1w(i,1:n_trials)=nan;

        sim_disbias_1w(i,1:2)=nan;
        sim_disbias_ind1_1w(i,1:n_trials)=nan;
        sim_disbias_ind2_1w(i,1:n_trials)=nan;

    else
    %indcg_func(dind, dind_std, dgist, dgist_std, subj)
       %sim_dindcg_1w(i,1) = indcg_func(dind_nolabel_1w(i,1), nanstd(dind_nolabel_1w(:,1)), dgist_1w(i,1), nanstd(dgist_1w(:,1)), n_sim); 
       %sim_dindcg_1w(i,2) = indcg_func(dind_nolabel_1w(i,2), nanstd(dind_nolabel_1w(:,2)), dgist_1w(i,2), nanstd(dgist_1w(:,2)), n_sim);
       
[sim_dindcg_1w(i,1), sim_bias_inds_avg_1w(i,1), sim_bias_inds1_1w(i,:), sim_disbias_ind1_1w(i,:), sim_disbias_1w(i,1)] = indcg_func(dinds1_1w(i,:), dotX_1w(i,:), dotY_1w(i,:), random_order2_1w(i,:), dgist_1w(i,1), n_sim); 
[sim_dindcg_1w(i,2), sim_bias_inds_avg_1w(i,2), sim_bias_inds2_1w(i,:), sim_disbias_ind2_1w(i,:), sim_disbias_1w(i,2)] = indcg_func(dinds2_1w(i,:), dotX_1w(i,:), dotY_1w(i,:), random_order3_1w(i,:), dgist_1w(i,2), n_sim); 

       %sim_dindcg_rely_1w(i,1) = indcg_func_rely(ind2, nanstd(dgist_1w(:,1)), n_sim); 
       %sim_dindcg_rely_1w(i,2) = indcg_func_rely(ind3, nanstd(dgist_1w(:,2)), n_sim);
              
    end   

end 

%savedot('1w', n_s, gist1_1w, gist2_1w, ind1X_1w, ind1Y_1w, ind2X_1w, ind2Y_1w, ...,
%dotX_1w, dotY_1w, random_order2_1w, random_order3_1w);

%savedot2('1w', n_s, gist1_1w, gist2_1w, ind1X_1w, ind1Y_1w, ind2X_1w, ind2Y_1w, ...,
%dotX_1w, dotY_1w, random_order2_1w, random_order3_1w);


clear bonus c_temp c_temp1 c_temp2 cs1w day1Time dontcare dotX dotY i ii;
clear enc_cen enc_ret gist1 gist2 gist_ceil gist1_dis gist2_dis gist_ceil_dis;
clear ind1 ind1_dis ind2 ind2_dis ind3 ind3_dis ind_order ind_temp lm lm_wrong;
clear n1 n2 P0 P1 P2 random1 random2 random_dot random_ind* ret_cen row_dgist;
clear t2_c T1Time temp_mat1 temp_mat2 dind2_tempa dind2_tempb T2Time;

save('1w.mat');


[p_dgist_1w, h_dgist_1w] = signrank(dgist_1w(:,1), dgist_1w(:,2));

[p_dind_1w, h_dind_1w] = signrank(dind_1w(:,1), dind_1w(:,2));


%bias measurement
[p_bias_angle_1w, h_bias1_angle_1w] = signrank(bias_angle_1w(:,1), bias_angle_1w(:,2));
[p_bias2_angle_1w, h_bias2_angle_1w] = signrank(bias_angle2_1w(:,1), bias_angle2_1w(:,2));
[p_disbias_1w, h_disbias_1w] = signrank(disbias_1w(:,1), disbias_1w(:,2));

[p_bias_inds1_1w, h_bias_inds1_1w] = signrank(bias_inds_1w(:,1), bias_inds_1w(:,2));
[p_bias_inds2_1w, h_bias_inds2_1w] = signrank(bias_inds2_1w(:,1), bias_inds2_1w(:,2));
 
[h_indcg_1w, p_indcg_1w] = ttest(dindcg_1w(:,1), dindcg_1w(:,2));

[R_img1_1w,p_img1_1w] = corrcoef(dindme_1w(:,1), dgist_1w(:,1), 'Rows','complete');
[R_img2_1w,p_img2_1w] = corrcoef(dindme_1w(:,2), dgist_1w(:,2), 'Rows','complete');

[R_dindg1_1w,p_dindg1_1w] = corrcoef(dind_1w(:,1), dgist_1w(:,1), 'Rows','complete');
[R_dindg2_1w,p_dindg2_1w] = corrcoef(dind_1w(:,2), dgist_1w(:,2), 'Rows','complete');

[R_dindg_min1_1w,p_dindg_min1_1w] = corrcoef(dind_min_1w(:,1), dgist_1w(:,1), 'Rows','complete');
[R_dindg_min2_1w,p_dindg_min2_1w] = corrcoef(dind_min_1w(:,2), dgist_1w(:,2), 'Rows','complete');


[R_dind_dindcg1_1w,p_dind_dindcg1_1w] = corrcoef(dind_1w(:,1), dindcg_1w(:,1), 'Rows','complete');
[R_dind_dindcg2_1w,p_dind_dindcg2_1w] = corrcoef(dind_1w(:,2), dindcg_1w(:,2), 'Rows','complete');


[h_var_dg1w, p_var_dg1w] = ansaribradley(dgist_1w(:,1),dgist_1w(:,2));



