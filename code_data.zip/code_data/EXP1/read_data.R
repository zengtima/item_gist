library("tidyr")
#read in the d
d24h1 <- read_csv('24h_data1.csv')
d24h2 <- read_csv('24h_data2.csv')
d1w1 <- read_csv('1w_data1.csv')
d1w2 <- read_csv('1w_data2.csv')
d1m1 <- read_csv('1m_data1.csv')
d1m2 <- read_csv('1m_data2.csv')

d24h1 <- na.omit(d24h1)
d24h2 <- na.omit(d24h2)

d24h1["group"] = '24 hours'
d24h2["group"] = '24 hours'

d1w1 <- na.omit(d1w1)
d1w2 <- na.omit(d1w2)
d1w1["group"] = '1 week'
d1w2["group"] = '1 week'

d1m1 <- na.omit(d1m1)
d1m2 <- na.omit(d1m2)
d1m1["group"] = '1 month'
d1m2["group"] = '1 month'

d1 = rbind(d24h1, d1w1, d1m1)
d2 = rbind(d24h2, d1w2, d1m2)

dall = rbind(d1,d2)

my_comparisons <- list(c("24 hours", "1 week"), c("24 hours", "1 month"), c("1 week", "1 month"))

#item and gist error change
var_errors = c("ID", "group", "dind", "dgist")
dchange_error = d2[var_errors]
dchange_error[dchange_error$group == '24 hours',c("dind", "dgist")] = d24h2[c("dind", "dgist")] - d24h1[c("dind", "dgist")]
dchange_error[dchange_error$group == '1 week',c("dind", "dgist")] = d1w2[c("dind", "dgist")] - d1w1[c("dind", "dgist")]
dchange_error[dchange_error$group == '1 month',c("dind", "dgist")] = d1m2[c("dind", "dgist")] - d1m1[c("dind", "dgist")]

memoryTypeLabs <- c(dind="Item", dgist="Center (Gist)") 
dchange_error = melt(dchange_error, id.vars = c("ID", "group"))
dchange_error = rename(dchange_error, c("value"="errorChange", "variable"="memoryType"))
dchange_error$group<- factor(dchange_error$group, levels = c("24 hours", "1 week", "1 month"))

dind_chance = 348
dgist_chance = 216


#bias change
var_bias = c("ID", "group", "bias", "bias_hcm")
dchange_bias = d2[var_bias]
dchange_bias[dchange_bias$group == '24 hours',c("bias", "bias_hcm")] = d24h2[c("bias", "bias_hcm")] - d24h1[c("bias", "bias_hcm")]
dchange_bias[dchange_bias$group == '1 week',c("bias", "bias_hcm")] = d1w2[c("bias", "bias_hcm")] - d1w1[c("bias", "bias_hcm")]
dchange_bias[dchange_bias$group == '1 month',c("bias", "bias_hcm")] = d1m2[c("bias", "bias_hcm")] - d1m1[c("bias", "bias_hcm")]

#biasTypeLabs <- c(bias="Item", dgist="Center (Gist)") 
#dchange_bias = melt(dchange_bias, id.vars = c("ID", "group"))
#dchange_bias = rename(dchange_bias, c("value"="biasChange", "variable"="biasType"))
dchange_bias$group<- factor(dchange_bias$group, levels = c("24 hours", "1 week", "1 month"))


#supplementary materials
#error values at session 1 and 2

d1_errors = d1[var_errors]
d1_errors = melt(d1_errors, id.vars = c("ID", "group"))
d1_errors = rename(d1_errors, c("value"="error", "variable"="memoryType"))
d1_errors$group<- factor(d1_errors$group, levels = c("24 hours", "1 week", "1 month"))

d1_errors$chance <- ifelse(d1_errors$memoryType == "dind", dind_chance, dgist_chance)

d2_errors = d2[var_errors]
d2_errors = melt(d2_errors, id.vars = c("ID", "group"))
d2_errors = rename(d2_errors, c("value"="error", "variable"="memoryType"))
d2_errors$group<- factor(d2_errors$group, levels = c("24 hours", "1 week", "1 month"))

d2_errors$chance <- ifelse(d2_errors$memoryType == "dind", dind_chance, dgist_chance)


#themes
themeFacet = theme(title = element_text(color = "black", size = 20, face = "plain"),
                   plot.title = element_text(hjust = 0.5),
                   axis.title = element_text(color = "black", size = 25, angle = 90, hjust = 1, vjust = .5, face = "plain"),
                   axis.text.x = element_text(color = "black", size = 25, angle = 0, hjust = .5, vjust = .5, face = "plain"),
                   axis.text.y = element_text(color = "black", size = 25, angle = 0, hjust = 1, vjust = 0, face = "plain"),  
                   axis.title.x = element_blank(),
                   axis.title.y = element_text(color = "black", size = 25, angle = 90, hjust = .5, vjust = .5, face = "plain"),
                   strip.text.x = element_text(size = 30, colour = "black"),
                   strip.background = element_blank(),
                   axis.ticks = element_blank(),
                   panel.border = element_blank(), 
                   panel.grid.major = element_blank(),
                   panel.grid.minor = element_blank(), 
                   legend.position='none')
