function [sim_bias_dis_ind, sim_bias_dis] ...
= baseline_bias(loc, dind, gist, subj, n_trials)

%number of simulation
for i = 1:subj
    
    %generated a simulated response for the item location
    %without assuming directions
    for j = 1:n_trials         
    
    %whether the simulated response is in the range of the screen
    pass = 0;
     
    while pass == 0
    toss = randi([1 4]);
    
    angle = (1/2)*pi*rand;
 
        if toss == 1
        rand_matX(j) = loc(j,1)+sin(angle)*dind(j); 
        rand_matY(j) = loc(j,2)+cos(angle)*dind(j);
        elseif toss == 2
        rand_matX(j) = loc(j,1)+sin(angle)*dind(j);  
        rand_matY(j) = loc(j,2)-cos(angle)*dind(j);
        elseif toss == 3
        rand_matX(j) = loc(j,1)-sin(angle)*dind(j);  
        rand_matY(j) = loc(j,2)+cos(angle)*dind(j);   
        else
        rand_matX(j) = loc(j,1)-sin(angle)*dind(j); 
        rand_matY(j) = loc(j,2)-cos(angle)*dind(j);    
        end
 
        if (rand_matX(j) <= 1440) && (rand_matX(j) >= 0) && (rand_matY(j) <= 900) && (rand_matY(j) >= 0)
            pass = 1;
        end
        
    end
    
    ind_matX(i, j) = rand_matX(j);
    ind_matY(i, j) = rand_matY(j);
    
    end
 
end
 

%bias simulation
    for i = 1:subj
        x_temp = ind_matX(i, :);
        y_temp = ind_matY(i, :);
        [sim_bias_dis_inds(i,:),sim_bias_dis_subj(i)] = bias_func(loc, [x_temp(:),y_temp(:)], gist);
    end

%distance
sim_bias_dis_ind = nanmean(sim_bias_dis_inds); %simulated bias of input locations for each real participant based on simulations
sim_bias_dis = nanmean(sim_bias_dis_subj); %simulated bias for each real participant based on simulations

end