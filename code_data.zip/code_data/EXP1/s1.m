%run the matlab analysis scripts to read the data and run simulations
%analysis_func is a matlab function that 
%reads and organizes raw data, generates baseline simulations, and saves these data for later analyses in r

%the input for analysis_func can be one of: '24h', '1w', '1m'
analysis_func('24h'); % 24 hours, output: 24h_data1.csv, 24h_data2.csv
analysis_func('1w');  % 1 week, output: 1w_data1.csv, 1w_data2.csv
analysis_func('1m');  % 1 month, output: 1m_data1.csv, 1m_data2.csv