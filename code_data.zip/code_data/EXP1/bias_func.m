
function [db_inds, db] = bias_func(enc, ret, cen)

    for i = 1:length(ret(:,1))
        
        if isnan(ret(i,1)) == 0
        
        %day 1
        enc_ret = pdist2(enc(i,:),ret(i,:),'euclidean');
        enc_cen = pdist2(enc(i,:),cen,'euclidean'); 
        ret_cen = pdist2(ret(i,:),cen,'euclidean'); 

    db_inds(i) = (enc_cen - ret_cen)/enc_ret;

        else
            
            db_inds(i) = nan;
  
        end
        
    end

    db = nanmean(db_inds);

end