cd stimuli_data;

load stimuli.mat;

loc(:,1) = dotX;
loc(:,2) = dotY;

loc = sortrows(loc,1);

n_trials = 6; 

megist = mean(loc);

error_start = 0;
error_max = 500;

error_step = 101;
error_inc = (error_max - error_start)/(error_step-1);


subj = 1000;

for e = 1:error_step

    error = error_start + e*error_inc;
    
    for i = 1:subj

        for j = 1:n_trials %j: # of locations

        pass = 0;

        while pass == 0
        toss = randi([1 4]);

        angle = (1/2)*pi*rand;

            if toss == 1
            rand_matX(j) = loc(j,1)+sin(angle)*error; 
            rand_matY(j) = loc(j,2)+cos(angle)*error;
            elseif toss == 2
            rand_matX(j) = loc(j,1)+sin(angle)*error;  
            rand_matY(j) = loc(j,2)-cos(angle)*error;
            elseif toss == 3
            rand_matX(j) = loc(j,1)-sin(angle)*error;  
            rand_matY(j) = loc(j,2)+cos(angle)*error;   
            else
            rand_matX(j) = loc(j,1)-sin(angle)*error; 
            rand_matY(j) = loc(j,2)-cos(angle)*error;    
            end

            if (rand_matX(j) <= 1440) && (rand_matX(j) >= 0) && (rand_matY(j) <= 900) && (rand_matY(j) >= 0)
                pass = 1;
            end

        end

        ind_loc_temp(j,:) = [rand_matX(j), rand_matY(j)];
        
        end
        
        bias_subj(e, i) = bias(loc, ind_loc_temp, megist);

    end

    error = 0;
    
end
 
bias_sim(:,1) = error_start:error_inc:error_max;
bias_sim(:,2) = mean(bias_subj,2);

save('bias_sim.mat', 'bias_sim');
