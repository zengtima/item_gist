function [learngist] = dinds_me(dotX, dotY)

n_trials = 6;

megist = [mean(dotX(1:n_trials)), mean(dotY(1:n_trials))];

for i = 1: n_trials
    
    tempx = dotX(i) - megist(1,1);
    tempy = dotY(i) - megist(1,2);
    
    distance_ind(i) = sqrt(tempx^2 + tempy^2);
    
end

learngist = min(distance_ind);

end

%gist chance performance: pdist2([720, 450],megist,'euclidean');
%215.3625

%ind chance performance: pdist2([720, 450],megist,'euclidean');
%215.3625

%for i = 1: n_trials
    
%    chance_ind(i) = pdist2([720, 450], [dotX(i), dotY(i)],'euclidean');
    
%end