function analysis_func(time)

if strcmp(time,'1w')
    n_s =65; %largest number of participant code, this is not number of participants
else
    n_s = 59;
end

cd stimuli_data;
load stimuli;
cd ..;

n_trials = 6; 

loc(:,1) = dotX;
loc(:,2) = dotY;

loc = sortrows(loc,1);

gistlearn = dinds_me(dotX, dotY);

%center of encoded locations: (x, y)
megist = [mean(dotX(1:n_trials)), mean(dotY(1:n_trials))];

n_sim = 1000; %number of simulations per participant
n_start = 1;

% gist tested both on day1 and day 2
for s = n_start:n_s
   
cd(['stimuli_data/' time]);    

if isfile([num2str(s) '_day1.mat']) && isfile([num2str(s) '_day2.mat']) 
    % data corresponding to the participant ID exists.
     
    load([num2str(s) '_day1.mat']);
    load([num2str(s) '_day2.mat']);        

    cd ../..;
    
%note that that ind2s are reported item locations for session 1
%and ind3s are reported item locations for session 2

%item memory errors for session 1 and 2
dinds1(s,:) = ind2_dis;
dinds2(s,:) = ind3_dis;

%item memory error for subject (average of all items) for session 1 and 2
dind(s,1) = mean(ind2_dis);
dind(s,2) = mean(ind3_dis);

%sort participants' reported item memory location (x,y) coordinates
%into order that corresponds to the encoded item locations (variable loc: sorted at the beginning of the scripts)
%session 1, the variables are named sort2 but it is for session 1
sort2_temp(:,1) = ind2_dis;
sort2_temp(:,2) = dotX(random_ind2);
sort2_temp(:,3) = dotY(random_ind2);
sort2_temp(:,4) = ind2(:,1); %reported item location X coordinates
sort2_temp(:,5) = ind2(:,2); %reported item location Y coordinates
[sort2_temp, sort2_order_temp] = sortrows(sort2_temp,2);
dind2_sort(s,:) = sort2_temp(:,1);
ind2X_sort(s,:) = sort2_temp(:,4);
ind2Y_sort(s,:) = sort2_temp(:,5);
ind2_sort(:,1) = sort2_temp(:,4);
ind2_sort(:,2) = sort2_temp(:,5);

sort3_temp(:,1) = ind3_dis;
sort3_temp(:,2) = dotX(random_ind3);
sort3_temp(:,3) = dotY(random_ind3);
sort3_temp(:,4) = ind3(:,1); %reported item location X coordinates
sort3_temp(:,5) = ind3(:,2); %reported item location Y coordinates
[sort3_temp, sort3_order_temp] = sortrows(sort3_temp,2);
dind3_sort(s,:) = sort3_temp(:,1);
ind3X_sort(s,:) = sort3_temp(:,4);
ind3Y_sort(s,:) = sort3_temp(:,5);
ind3_sort(:,1) = sort3_temp(:,4);
ind3_sort(:,2) = sort3_temp(:,5);

%%gist memory: center%%
%reported gist memory error
dgist(s,1) = gist1_dis;
dgist(s,2) = gist2_dis;

%reported gist memory location (x,y) coordinates
res_gist1(s, 1:2) = gist1;
res_gist2(s, 1:2) = gist2;

%estimated gist memory location from reported items
%session 1
c_temp = mean(ind2)-megist;
indme1(s,1:2) = mean(ind2); %(x,y) coordinates
dindme(s,1) = sqrt(c_temp(1)^2 + c_temp(2)^2); %error

%session 2
c_temp = mean(ind3)-megist;
indme2(s,1:2) = mean(ind3); %(x,y) coordinates
dindme(s,2) = sqrt(c_temp(1)^2 + c_temp(2)^2); %error

%% bias %%
% absolute bias - reported center %
[disbias_inds1(s, :), disbias(s, 1)] = bias_func(loc, ind2_sort, gist1); %session 1

[disbias_inds2(s, :), disbias(s, 2)] = bias_func(loc, ind3_sort, gist2); %session 2

% baseline bias - reported center %
[sim_disbias_inds1(s, :), sim_disbias(s, 1)] = baseline_bias(loc, dind2_sort(s,:), gist1, n_sim, n_trials); %session 1

[sim_disbias_inds2(s, :), sim_disbias(s, 2)] = baseline_bias(loc, dind3_sort(s,:), gist2, n_sim, n_trials); %session 2

% absolute bias - center of encoded locations %
[disbias_inds1_hcm(s, :), disbias_hcm(s, 1)] = bias_func(loc, ind2_sort, megist); %session 1

[disbias_inds2_hcm(s, :), disbias_hcm(s, 2)] = bias_func(loc, ind3_sort, megist); %session 2

% baseline bias - center of encoded locations %
[sim_disbias_inds1_hcm(s, :), sim_disbias_hcm(s, 1)] = baseline_bias(loc, dind2_sort(s,:), megist, n_sim, n_trials); %session 1

[sim_disbias_inds2_hcm(s, :), sim_disbias_hcm(s, 2)] = baseline_bias(loc, dind3_sort(s,:), megist, n_sim, n_trials); %session 2

else %if no data for the participant ID
    
    cd ../..;

    dind(s,1:2) = nan;   
    dinds1(s, 1:n_trials) = nan;
    dinds2(s, 1:n_trials) = nan;
    
    dgist(s,1:2) = nan;
    res_gist1(s,1:2) = nan;
    res_gist2(s,1:2) = nan;
    
    dindme(s,1:2) = nan;    
    indme1(s,1:2) = nan;
    indme2(s,1:2) = nan;

    disbias(s,1:2) = nan;
    disbias_inds1(s,1:n_trials) = nan;
    disbias_inds2(s,1:n_trials) = nan;
    sim_disbias(s,1:2) = nan;
    sim_disbias_inds1(s,1:n_trials) = nan;
    sim_disbias_inds2(s,1:n_trials) = nan;

    disbias_hcm(s,1:2) = nan;
    disbias_inds1_hcm(s,1:n_trials) = nan;
    disbias_inds2_hcm(s,1:n_trials) = nan;
    sim_disbias_hcm(s,1:2) = nan;
    sim_disbias_inds1_hcm(s,1:n_trials) = nan;
    sim_disbias_inds2_hcm(s,1:n_trials) = nan;

end    


end

bias = disbias - sim_disbias;

bias_hcm = disbias_hcm - sim_disbias_hcm;

%performance of gist memory lower than chance at session 1 (performance worse than putting the center at the center of the screen)
%considered as not learning or not following instruction
notlearngist_ses1 = find(dgist(:,1) >= gistlearn); 
dgist(notlearngist_ses1,:) = nan;

%participants whose gist and item errors were outlier at each session
ol_dgist1 = isoutlier(dgist(:,1), 'mean');
ol_dind1 = isoutlier(dind(:,1), 'mean');

ol_dgist2 = isoutlier(dgist(:,2), 'mean');
ol_dind2 = isoutlier(dind(:,2), 'mean');

%exclude the participants identified above
dgist(ol_dgist1,:) = nan;
dgist(ol_dind1,:) = nan;
dgist(ol_dgist2,:) = nan;
dgist(ol_dind2,:) = nan;

%identified the ID of participants excluded
[row_dgist, dontcare] = find(isnan(dgist(:,1)) == 1);

%%save the data%%

cd s1_output; 

label = {'ID';'day';'dind';'dgist'; 'dindme'; ...
    'bias'; 'bias_hcm'; 'disbias'; 'sim_disbias'; 'disbias_hcm';'sim_disbias_hcm'};

%session 1
data1(:,1) = 1:n_s; %ID
data1(:,2) = 1; %day/session
data1(:,3) = dind(:,1); %item error
data1(:,4) = dgist(:,1); %center error
data1(:,5) = dindme(:,1); %estimated center error
data1(:,6) = bias(:,1); %bias = absolute bias - baseline bias (reported center)
data1(:,7) = bias_hcm(:,1); %bias = absolute bias - baseline bias (center of encoded item locations)
data1(:,8) = disbias(:,1); %absolute bias (reported center)
data1(:,9) = sim_disbias(:,1); %baseline bias (reported center)
data1(:,10) = disbias_hcm(:,1); %absolute bias (center of encoded item locations)
data1(:,11) = sim_disbias_hcm(:,1); %baseline bias (center of encoded item locations)

data1(row_dgist,:) = nan;

data1Table = array2table(data1,'VariableNames',label);
writetable(data1Table, [time '_data1.csv'])


%session 2
data2(:,1) = 1:n_s; %ID
data2(:,2) = 2; %day/session
data2(:,3) = dind(:,2); %item error
data2(:,4) = dgist(:,2); %center error
data2(:,5) = dindme(:,2); %estimated center error
data2(:,6) = bias(:,2); %bias = absolute bias - baseline bias (reported center)
data2(:,7) = bias_hcm(:,2); %bias = absolute bias - baseline bias (center of encoded item locations)
data2(:,8) = disbias(:,2); %absolute bias (reported center)
data2(:,9) = sim_disbias(:,2); %baseline bias (reported center)
data2(:,10) = disbias_hcm(:,2); %absolute bias (center of encoded item locations)
data2(:,11) = sim_disbias_hcm(:,2); %baseline bias (center of encoded item locations)

data2(row_dgist,:) = nan;

data2Table = array2table(data2,'VariableNames',label);
writetable(data2Table, [time '_data2.csv'])

cd ..;

%%